<img width="972" height="801" alt="image" src="https://github.com/user-attachments/assets/172e3883-09fb-41fb-83b6-4cd39a8329bc" />
